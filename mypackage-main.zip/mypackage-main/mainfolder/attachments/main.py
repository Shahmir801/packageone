import os
from os import mkdir, sys, system
from sys import argv
path=sys.argv[1]
MAIN_DIR=os.getcwd()
system("mkdir src")
system("cp -a "+path+"/. "+MAIN_DIR+"/src")
require=""
require1=""
file=open(MAIN_DIR+"/src/requirements.txt",'r')
l=file.readlines()
count=1
for i in l:
    ns=""
    for j in range(len(i)):
        if j!=len(i)-1:
            ns = ns + i[j]
    if count==1:
        require=require+"'"+ns+"'"
        require1=require1+ns
    else:
        require=require+','+"'"+ns+"'"
        require1=require1+','+ns
    count+=1
data=["from setuptools import setup, find_packages\nsetup(\n\t",
        "name='"+sys.argv[2]+"',\n","\tversion='"+argv[3]+"',\n",
        "\tdescription='"+argv[4]+"',\n","\turl='"+argv[5]+"',\n",
        "\tauthor='"+argv[6]+"',\n","\tauthor_email='"+argv[7]+"',\n",
        "\tlicence='"+argv[8]+"',\n","\tinstall_requires=["+require+"]\n",")"]
file1=open(MAIN_DIR+"/setup.py",'w+')
file1.writelines(data)
system("mkdir debian")
system("touch debian/rules")
system("touch debian/control")
system("touch debian/compat")
system("dch --create")
data1=["Source: "+argv[2]+"\n",
        "Maintainer: "+argv[6]+" <"+argv[7]+">\n",
        "Build-Depends: debhelper,dh-python,python3-all,python3-setuptools\n",
        "Section: devel\nPriority: optional\nStandards-Version: 3.9.6\nX-Python3-Version: >= 3.6\n\nPackage: "+argv[2]+"\nArchitecture: all\nDescription: "+argv[4]+".\nDepends: ${python3:Depends},"+require1+"\n"]
file2=open(MAIN_DIR+"/debian/control",'w+')
file2.writelines(data1)
data2=["#! /usr/bin/make -f\n",
        "#export DH_VERBOSE = 1\n",
        "export PYBUILD_NAME = mypackage\n",
        "%:\n",
        "\tdh $@ --with python3 --buildsystem=pybuild"]
file3=open(MAIN_DIR+"/debian/rules",'w+')
file3.writelines(data2)
file4=open(MAIN_DIR+"/debian/compat",'w+')
file4.write("10")
